/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java2ddrawingapplication;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Paint;
import java.awt.Point;
import java.awt.Stroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author acv
 */
public class DrawingApplicationFrame extends JFrame
{

    // Create the panels for the top of the application. One panel for each
    // line and one to contain both of those panels.
    JPanel firstLine = new JPanel();
    JPanel secondLine = new JPanel();
    JPanel topPanel = new JPanel();
    DrawPanel drawPanel = new DrawPanel();

    // create the widgets for the firstLine Panel.
    JButton undo = new JButton("Undo");
    JButton clear = new JButton("Clear");
    ArrayList<MyShapes> shapesList = new ArrayList<>();
    JComboBox shape = new JComboBox<>(new String[] {"Line", "Oval", "Rectangle"});
    JCheckBox filled = new JCheckBox("Filled");

    //create the widgets for the secondLine Panel.
    JCheckBox gradient = new JCheckBox("Use Gradient");
    JButton colorOne = new JButton("1st Color...");
    JButton colorTwo = new JButton("2nd Color...");
    JTextField lineWidth = new JTextField("1");
    JTextField dashLength = new JTextField("1");
    JCheckBox dashed = new JCheckBox("Dashed");
    JLabel width = new JLabel("Line Width:");
    JLabel length = new JLabel("Dash Length:");
    

    // Variables for drawPanel.
    Color color1 = Color.BLACK;
    Color color2 = Color.BLACK;

    // add status label
    JLabel statusLabel = new JLabel("( , )");
    
    // Constructor for DrawingApplicationFrame
    public DrawingApplicationFrame()
    {
        super("Java 2D Drawings");
        // add widgets to panels
        firstLine.add(undo);
        firstLine.add(clear);
        firstLine.add(shape);
        firstLine.add(filled);

        // firstLine widgets

        // secondLine widgets
        secondLine.add(gradient);
        secondLine.add(colorOne);
        secondLine.add(colorTwo);
        secondLine.add(width);
        secondLine.add(lineWidth);
        secondLine.add(length);
        secondLine.add(dashLength);
        secondLine.add(dashed);
        colorHandler colHandler = new colorHandler();
        colorOne.addActionListener(colHandler);
        colorTwo.addActionListener(colHandler);
        undo.addActionListener(new UndoHandler());
        clear.addActionListener(new clearHandler());

        // add top panel of two panels
        topPanel.setLayout(new GridLayout(2, 1));
        firstLine.setLayout(new FlowLayout());
        firstLine.setVisible(true);
        topPanel.add(firstLine);
        topPanel.add(secondLine);

        // add topPanel to North, drawPanel to Center, and statusLabel to South
        add(topPanel, BorderLayout.NORTH);
        add(drawPanel, BorderLayout.CENTER);
        add(statusLabel, BorderLayout.SOUTH);

        
        //add listeners and event handlers

    }

    // Create event handlers, if needed
    public class UndoHandler implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            if(shapesList.size() != 0){
                shapesList.remove(shapesList.size() - 1);
                repaint();
            }
        }
    }
    
    public class clearHandler implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            shapesList.clear();
            repaint();
        }
    }
    
    public class colorHandler implements ActionListener{
        
        @Override
        public void actionPerformed(ActionEvent e) {
           Color color = Color.BLACK;
           color = JColorChooser.showDialog(null, "Choose a color", color);
           if(color == null)
               color = Color.BLACK;
           else if(e.getSource() == colorOne) {
               color1 = color;
           }
           else
               color2 = color;
        }
    }
        
    

    // Create a private inner class for the DrawPanel.
    private class DrawPanel extends JPanel
    {

        public DrawPanel()
        {
            setBackground(Color.WHITE);
            MouseHandler handler = new MouseHandler();
            addMouseListener(handler);
            addMouseMotionListener(handler);
            
        }

        public void paintComponent(Graphics g)
        {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            for(MyShapes shape: shapesList) {
                shape.draw(g2d);
            }
            //loop through and draw each shape in the shapes arraylist

        }


        private class MouseHandler extends MouseAdapter implements MouseMotionListener
        {
            private Point clickPoint;
            MyShapes currentShape;
            
            public void mousePressed(MouseEvent event)
            {
                // check and add to shapesList
                Paint paint = new GradientPaint(0, 0, color1, 50, 50, color1, true);
                
                if(gradient.isSelected()){
                    paint = new GradientPaint(0, 0, color1, 50, 50, color2, true);
                }
                BasicStroke stroke;
                
                float linewidth = Float.parseFloat(lineWidth.getText());
                float[] dashlength = new float[1];
                dashlength[0] = Float.parseFloat(dashLength.getText());
                
                if (dashed.isSelected())
                {
                    stroke = new BasicStroke(linewidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 10, dashlength, 0);
                } else
                {
                    stroke = new BasicStroke(linewidth, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
                }
                
                String selected = (String) shape.getSelectedItem();
                
                if(selected == "Line"){
                    currentShape = new MyLine(event.getPoint(), event.getPoint(), paint, stroke);
                }else if(selected == "Rectangle"){
                    currentShape = new MyRectangle(event.getPoint(), event.getPoint(), paint, stroke, filled.isSelected());
                } else {
                    currentShape = new MyOval(event.getPoint(), event.getPoint(), paint, stroke, filled.isSelected());
                }
                
                shapesList.add(currentShape);
                repaint();
                
                
            }

            public void mouseReleased(MouseEvent event)
            {
            }

            @Override
            public void mouseDragged(MouseEvent event)
            {
                currentShape.setEndPoint(event.getPoint());
                repaint();
            }

            @Override
            public void mouseMoved(MouseEvent event)
            {
                String position = "(" + event.getPoint().x + "," + event.getPoint().y + ")";
		statusLabel.setText(position);
            }
        }

    }
}
